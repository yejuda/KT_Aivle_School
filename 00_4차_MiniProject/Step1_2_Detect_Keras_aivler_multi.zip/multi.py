import cv2
import numpy as np
from tensorflow.keras.models import load_model

from Step0_etc_pretrained_def import scaling, conv2d_bn, _generate_layer_name, _inception_resnet_block

modelA = load_model("A_feacenet_weight_4_layer_1.keras")
modelA_asia = load_model("A_asia_model.keras")
modelB_asia = load_model("B_asia_model.keras")
modelD = load_model("D_feacenet_weight_4_layer_1.keras")

cap = cv2.VideoCapture(0)
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

if not cap.isOpened() :
    print('카메라 실행 불가')
    exit()

while True :
    ret, frame = cap.read()
    if not ret :
        print('프레임 로드 불가')
        break
    
    frame = cv2.flip(frame, 1)
    gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    faces = face_cascade.detectMultiScale(gray_frame)
    
    frame_copy1 = frame.copy()
    frame_copy2= frame.copy()
    frame_copy3 = frame.copy()

    for (x,y,w,h) in faces :
        face_resized_model1 = cv2.resize(frame, (160,160) )
        face_resized_model2 = cv2.resize(frame_copy1, (160,160) )
        face_resized_model3 = cv2.resize(frame_copy2, (160,160) )
        face_resized_model4 = cv2.resize(frame_copy3, (160,160) )

        face_resized_model1 = face_resized_model1 / 255.0
        face_resized_model2 = face_resized_model2 / 255.0
        face_resized_model3 = face_resized_model3 / 255.0
        face_resized_model4 = face_resized_model4 / 255.0

        face_resized_model1 = np.expand_dims(face_resized_model1, axis=0)
        face_resized_model2 = np.expand_dims(face_resized_model2, axis=0)
        face_resized_model3 = np.expand_dims(face_resized_model3, axis=0)
        face_resized_model4 = np.expand_dims(face_resized_model4, axis=0)
        
        y_pred_model_1 = modelA.predict(face_resized_model1)
        y_pred_model_2 = modelA_asia.predict(face_resized_model2)
        y_pred_model_3 = modelB_asia.predict(face_resized_model3)
        y_pred_model_4 = modelD.predict(face_resized_model4)

        if y_pred_model_1[0][0] >= 0.5 :
            color = (0,255,0)
            prob = y_pred_model_1[0][0]*100
            label_text = f'ModelA - My Face prob : {prob:.2f}%'
        else :
            color = (0,0,255)
            prob = y_pred_model_1[0][0]*100
            label_text = f'ModelA - Other Face prob : {prob:.2f}%'

        cv2.rectangle(frame, (x,y), (x+w, y+h), color, 2)
        cv2.putText(frame, label_text, (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)

        if y_pred_model_2[0][0] >= 0.5 :
            color = (0,255,0)
            prob = y_pred_model_2[0][0]*100
            label_text = f'ModelA_asia - My Face prob : {prob:.2f}%'
        else :
            color = (0,0,255)
            prob = y_pred_model_2[0][0]*100
            label_text = f'ModelA_asia - Other Face prob : {prob:.2f}%'
        
        cv2.rectangle(frame_copy1, (x,y), (x+w, y+h), color, 2)
        cv2.putText(frame_copy1, label_text, (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)
        
        if y_pred_model_3[0][0] >= 0.5 :
            color = (0,255,0)
            prob = y_pred_model_3[0][0]*100
            label_text = f'ModelB_asia - My Face prob : {prob:.2f}%'
        else :
            color = (0,0,255)
            prob = y_pred_model_3[0][0]*100
            label_text = f'ModelB_asia - Other Face prob : {prob:.2f}%'
        
        cv2.rectangle(frame_copy2, (x,y), (x+w, y+h), color, 2)
        cv2.putText(frame_copy2, label_text, (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)
        
        if y_pred_model_4[0][0] >= 0.5 :
            color = (0,255,0)
            prob = y_pred_model_4[0][0]*100
            label_text = f'ModelD - My Face prob : {prob:.2f}%'
        else :
            color = (0,0,255)
            prob = y_pred_model_4[0][0]*100
            label_text = f'ModelD - Other Face prob : {prob:.2f}%'
        
        cv2.rectangle(frame_copy3, (x,y), (x+w, y+h), color, 2)
        cv2.putText(frame_copy3, label_text, (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)
    
    cv2.imshow('Face_Detection_model1', frame)
    cv2.imshow('Face_Detection_model2', frame_copy1)
    cv2.imshow('Face_Detection_model3', frame_copy2)
    cv2.imshow('Face_Detection_model4', frame_copy3)
    
    if cv2.waitKey(1) & 0xFF == ord('q') :
        break

cap.release()
cv2.destroyAllWindows()