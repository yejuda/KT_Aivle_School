import os
import cv2

def crop_faces_with_opencv(input_dir, output_dir, test_mode=False):
    # Output directory가 없으면 생성
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    # Haar Cascade 분류기 로드 (얼굴 인식을 위함)
    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    
    # Input directory의 모든 파일 순회
    for i, filename in enumerate(os.listdir(input_dir)):
        # 테스트 모드일 경우 처음 10개의 이미지만 처리
        if test_mode and i >= 10:
            print("Test mode: Processed 10 images. Stopping.")
            break
        
        file_path = os.path.join(input_dir, filename)
        
        # 이미지 읽기
        image = cv2.imread(file_path)
        if image is None:
            print(f"Could not read image {filename}. Skipping.")
            continue

        # 이미지 그레이스케일 변환
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        
        # 얼굴 검출
        faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))
        
        # 얼굴이 발견된 경우, 각 얼굴 부분을 crop
        for i, (x, y, w, h) in enumerate(faces):
            # 얼굴 부분만 crop
            face_image = image[y:y+h, x:x+w]
            
            # 파일 이름을 생성 (ex. originalname_face0.jpg)
            output_path = os.path.join(output_dir, f"{os.path.splitext(filename)[0]}_face{i}.jpg")
            
            # 얼굴 이미지를 output directory에 저장
            cv2.imwrite(output_path, face_image)
            print(f"Saved cropped face to {output_path}")

# 디렉터리 경로 설정
input_directory = "C:/Users/User/Desktop/project4/original_images/original_images"
output_directory = "C:/Users/User/Desktop/project4/original_images/crop"

# 얼굴을 crop하여 저장
crop_faces_with_opencv(input_directory, output_directory, test_mode=True) # 전체 crop 진행할 경우 test_mode=False로 수정 후 실행
