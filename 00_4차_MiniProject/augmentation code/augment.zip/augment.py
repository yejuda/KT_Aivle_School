import os
import imageio
import numpy as np
import imgaug as ia
from imgaug import augmenters as iaa
from sklearn.utils import shuffle

ia.seed(1)

# Load images
input_folder_path = 'C:/Users/User/Desktop/project4/my_face_test'
output_folder_path = 'C:/Users/User/Desktop/project4/my_face_aug'
image_file_names = os.listdir(input_folder_path)
images = [imageio.imread(os.path.join(input_folder_path, file)) for file in image_file_names]

# shuffle images
images = shuffle(images, random_state=42)

# Define the augmented sequences
augmentations = [
    iaa.AdditiveGaussianNoise(scale=0.1*255),   # Gaussian Noise
    iaa.LogContrast(gain=(0.5, 1.0)),   # Log contrast
    iaa.Sharpen(alpha=1.0),  # Enhance Sharpness
    iaa.GaussianBlur(sigma=0.5),  # Gaussian Blur
    iaa.MotionBlur(k=10, angle=144)  # Motion Blur
]

# #TEST
# for i, image in enumerate(images):
#     if i < 2:
#         augmented_images = augmentations[0].augment_images([image])
#     elif i < 4:
#         augmented_images = augmentations[1].augment_images([image]*3)
#     elif i < 6:
#         augmented_images = augmentations[2].augment_images([image])
#     elif i < 8:
#         augmented_images = augmentations[3].augment_images([image])
#     elif i<10:
#         augmented_images = augmentations[4].augment_images([image])
#     else:
#         break

for i, image in enumerate(images):
    if i < 500:
        augmented_images = augmentations[0].augment_images([image])
    elif i < 1000:
        augmented_images = augmentations[1].augment_images([image]*3)
    elif i < 1500:
        augmented_images = augmentations[2].augment_images([image])
    elif i < 2000:
        augmented_images = augmentations[3].augment_images([image])
    else:
        augmented_images = augmentations[4].augment_images([image])


    # Save augmented images
    for j, aug_image in enumerate(augmented_images):
        imageio.imwrite(f'{output_folder_path}/img_{i}_{j}.jpg', aug_image)